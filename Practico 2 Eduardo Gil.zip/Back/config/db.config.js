module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "root",
    DB: "Web2Prac2",
    PORT: 3306
};
